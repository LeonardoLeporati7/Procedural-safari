extends Marker3D

@onready var object = $".." 

@export var step_target: Node3D 
@export var step_distance: float = 2.0 
@export var animation_duration: float = 0.2
@export var adjacent_target: Node3D 
@export var opposite_target: Node3D 

@export var isFront = false

var is_stepping := false

func _process(delta):
	# --- 1. GESTIONE SALTO ---
	if "is_jumping" in object and object.is_jumping:
		_handle_jump_pose(delta)
		return 

	# --- 2. GESTIONE CAMMINATA ---
	step_distance = 3.0 # Default
	animation_duration = 0.2 # Default
	
	if object.dir != 0: 
		# --- IN MOVIMENTO ---
		# Calcolo dinamico basato sulla velocità
		animation_duration = clamp(0.2 / (object.move_speed / 2.0), 0.05, 0.3)
		step_distance = 3.0 + (object.move_speed * 0.1)	
	
		if object.move_speed > 5: # CORSA
			if !is_stepping && !opposite_target.is_stepping && abs(global_position.distance_to(step_target.global_position)) > step_distance:
				step()
		else: # CAMMINATA
			if !is_stepping && !adjacent_target.is_stepping && abs(global_position.distance_to(step_target.global_position)) > step_distance:
				step()
				
	else:
		# --- IDLE (FERMO) ---
		# ATTENZIONE: Se metti 0.1, basta un respiro o una vibrazione della fisica
		# per far scattare un passo infinito.
		step_distance = 0.5 # Aumentato un po' per stabilità
		
		# Controlliamo se siamo troppo lontani dalla posizione di riposo
		if !is_stepping and abs(global_position.distance_to(step_target.global_position)) > step_distance:
			# Qui non controlliamo gli altri target, se sei fermo e scomodo, ti sistemi
			step()

# Funzione salto (che avevi lasciato a metà)
func _handle_jump_pose(delta):
	var v_vel = 0.0
	if "vertical_velocity" in object: v_vel = object.vertical_velocity
	
	var target_off = Vector3.ZERO
	if isFront:
		if v_vel > 0: # Salita
			target_off += object.transform.basis.y * 0.6 - object.transform.basis.z * 0.3
		else: # Discesa
			target_off -= object.transform.basis.y * 0.4 - object.transform.basis.z * 0.5
	else:
		if v_vel > 0: target_off -= object.transform.basis.y * 0.2
		else: target_off -= object.transform.basis.y * 0.5

	# Usiamo LERP per seguire fluidamente il corpo in aria
	var target_air_pos = step_target.global_position + target_off
	global_position = global_position.lerp(target_air_pos, 10.0 * delta)
	is_stepping = false # Resettiamo lo step mentre siamo in aria

func step():
	is_stepping = true
	var target_pos = step_target.global_position
	
	# DEBUG REALE: Stampiamo dove VORREMMO andare
	# print("Inizio passo verso: ", target_pos.y)

	var half_way = (global_position + target_pos) / 2
	var lift = owner.basis.y * (0.5 + object.move_speed * 0.1)
	
	var t = get_tree().create_tween()
	t.set_trans(Tween.TRANS_SINE) # Movimento più naturale
	
	# Prima metà del passo (salita)
	t.tween_property(self, "global_position", half_way + lift, animation_duration * 0.5)
	
	# Seconda metà del passo (discesa sul target)
	t.tween_property(self, "global_position", target_pos, animation_duration * 0.5)
	
	# Callback finale: Ora siamo arrivati!
	t.tween_callback(func(): 
		is_stepping = false
		# DEBUG REALE: Stampa qui per vedere se è arrivato giusto
		# print("Passo finito. Posizione attuale: ", global_position.y, " Target era: ", target_pos.y)
	)
