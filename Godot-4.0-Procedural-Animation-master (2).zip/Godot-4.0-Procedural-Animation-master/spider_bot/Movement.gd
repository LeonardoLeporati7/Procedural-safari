extends Node3D

@export var move_speed: float = 2.0
@export var turn_speed: float = 1.0
@export var ground_offset: float = 0.5 # Altezza base
@export var dir = 0
@export var is_attacking := false 


@export var jump_force: float = 8.0   # Potenza del salto
@export var gravity: float = 20.0     # Gravità (più è alta, più scendi veloce)
var vertical_velocity: float = 0.0    # Velocità verticale attuale
var is_jumping: bool = false          # Stato del salto
# ------------------------------------

@onready var fl_leg = $FrontLeftIKTarget
@onready var fr_leg = $FrontRightIKTarget
@onready var bl_leg = $BackLeftIKTarget
@onready var br_leg = $BackRightIKTarget

@onready var rc_fl = $StepTargetContainer/FrontLeftRay
@onready var rc_fr = $StepTargetContainer/FrontRightRay
@onready var rc_bl = $StepTargetContainer/BackLeftRay
@onready var rc_br = $StepTargetContainer/BackRightRay

func _process(delta):
	var plane1 = Plane(rc_bl.step_target.global_position, rc_fl.step_target.global_position, rc_fr.step_target.global_position)
	var plane2 = Plane(rc_fr.step_target.global_position, rc_br.step_target.global_position, rc_bl.step_target.global_position)
	var avg_normal = ((plane1.normal + plane2.normal) / 2).normalized()
	
	var target_basis = _basis_from_normal(avg_normal)
	transform.basis = lerp(transform.basis, target_basis, move_speed * delta).orthonormalized()
	
	var avg = (fl_leg.position + fr_leg.position + bl_leg.position + br_leg.position) / 4
	var target_pos = avg + transform.basis.y * ground_offset
	
	if Input.is_action_just_pressed("ui_accept") and !is_jumping: # "ui_accept" è solitamente SPAZIO
		is_jumping = true	
		vertical_velocity = jump_force
	
	if is_jumping:
	
		vertical_velocity -= gravity * delta # Applica gravità
		position.y += vertical_velocity * delta # Muovi su/giù
		
		if vertical_velocity < 0 and position.y <= target_pos.y:
			is_jumping = false
			vertical_velocity = 0.0
			position.y = target_pos.y
			
	else:
		var distance = transform.basis.y.dot(target_pos - position)
		position = lerp(position, position + transform.basis.y * distance, move_speed * delta)
	
	_handle_movement(delta)
	
func _handle_movement(delta):
	dir = Input.get_axis('ui_down', 'ui_up')
	translate(Vector3(0, 0, -dir) * move_speed * delta)
	
	var a_dir = Input.get_axis('ui_right', 'ui_left')
	rotate_object_local(Vector3.UP, a_dir * turn_speed * delta)

func _basis_from_normal(normal: Vector3) -> Basis:
	var result = Basis()
	result.x = normal.cross(transform.basis.z)
	result.y = normal
	result.z = transform.basis.x.cross(normal)

	result = result.orthonormalized()
	result.x *= scale.x 
	result.y *= scale.y 
	result.z *= scale.z 
	
	return result
