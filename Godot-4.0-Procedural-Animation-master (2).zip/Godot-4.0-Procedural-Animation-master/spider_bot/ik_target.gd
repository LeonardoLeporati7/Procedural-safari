extends Marker3D

@onready var object = $".." # Riferimento al padre (Movement)

@export var step_target: Node3D
@export var step_distance: float = 3.0
@export var animation_duration: float = 0.2
@export var adjacent_target: Node3D
@export var opposite_target: Node3D

@export var isFront = false;

var is_stepping := false

func _process(delta):
	# --- 1. GESTIONE SALTO (Priorità assoluta) ---
	# Se l'oggetto sta saltando, gestiamo SOLO la posizione aerea e ci fermiamo.
	if "is_jumping" in object and object.is_jumping:
		_handle_jump_pose(delta)
		return # <--- IMPORTANTE: Esce dalla funzione! Ignora la camminata sotto.
	
	# --- 2. GESTIONE CAMMINATA/CORSA ---
	# (Questo codice viene eseguito solo se NON stiamo saltando)
	
	animation_duration = 0.2
	step_distance = 3.0
	
	# Adattamento velocità
	if object.dir != 0:
		# Nota: Ho corretto la matematica qui per evitare numeri troppo piccoli/grandi
		animation_duration = clamp(0.2 / (object.move_speed / 2.0), 0.05, 0.3)
		step_distance = 3.0 + (object.move_speed * 0.1)

	# Logica Corsa vs Camminata
	if object.move_speed > 5:
		# CORSA
		if !is_stepping && !opposite_target.is_stepping && abs(global_position.distance_to(step_target.global_position)) > step_distance:
			step()
			# Nota: await in _process è pericoloso, ma lo lascio come nel tuo originale
			await get_tree().create_timer(0.1).timeout 
			if adjacent_target: adjacent_target.step()
			
	else:
		# CAMMINATA
		if !is_stepping && !adjacent_target.is_stepping && abs(global_position.distance_to(step_target.global_position)) > step_distance:
			step()
			await get_tree().create_timer(0.2).timeout
			if opposite_target: opposite_target.step()

# Nuova funzione per gestire la posa durante il salto
func _handle_jump_pose(delta):
	# Calcoliamo dove deve stare la zampa mentre vola.
	# step_target è attaccato alla spalla (tramite Raycast), quindi usiamolo come base.
	var target_air_pos = step_target.global_position
	
	if isFront:
		# Zampe ANTERIORI: Le tiriamo su (Tuck) verso la pancia
		# Usiamo basis.y (su locale) e basis.z (avanti locale)
		target_air_pos += (object.transform.basis.y * 0.5) # Alza di 0.5
		target_air_pos -= (object.transform.basis.z * 0.2) # Indietreggia un po'
	else:
		# Zampe POSTERIORI: Le lasciamo pendere un po' o le allunghiamo
		target_air_pos -= (object.transform.basis.y * 0.2) # Scendi un po'

	# Usiamo LERP invece di Tween, perché target_air_pos cambia mentre la volpe vola!
	global_position = global_position.lerp(target_air_pos, 10.0 * delta)
	
	# Assicuriamoci che lo stato del passo sia resettato per l'atterraggio
	is_stepping = false

func step():
	var target_pos = step_target.global_position
	var half_way = (global_position + step_target.global_position) / 2
	is_stepping = true
	
	# Animazione Passo (Qui il Tween va bene perché è un evento singolo)
	var t = get_tree().create_tween()
	t.tween_property(self, "global_position", half_way + owner.basis.y, animation_duration)
	t.tween_property(self, "global_position", target_pos, animation_duration)
	t.tween_callback(func(): is_stepping = false)
